# Class for processing MDF log file in Lambda function
class ProcessMdfData:
    # Initialize class
    def __init__(self, s3_client,decoder, bucket_input, s3_object_path, tmp_input_dir, tmp_output_dir):
        import logging
        
        self.logger = logging.getLogger()
        self.s3_client = s3_client
        self.decoder = decoder
        self.bucket_input = bucket_input
        self.s3_object_path = s3_object_path
        self.tmp_input_dir = tmp_input_dir
        self.tmp_output_dir =  tmp_output_dir 
        self.fs_log_file_path = self.tmp_input_dir / self.s3_object_path.name
    
        if any(self.tmp_input_dir.rglob("*")) or any(self.tmp_output_dir.rglob("*")):
            self.logger.info("Temporary directories created are not empty")
        
        
    # Extract device ID (note: Only works if the CANedge S3 file structure is used)
    def extract_device_id(self):
        import re
        
        device_id = ""
        parts = self.s3_object_path.parts
        
        # Check if the path has at least 3 parts and 1st part matches device ID syntax
        if len(parts) == 3 and re.match("[0-9A-F]{8}$", parts[0]):
            # The device_id is expected to be the first part of the path
            device_id = parts[0]
            self.logger.info(f"Device ID: {device_id}")
        else:
            self.logger.info(f"Unable to extract device_id (log file does not use CANedge S3 path)")
        
        return device_id
    
    
    # Download dbc-groups.json file (if it exists) and use device ID to extract relevant DBC list
    def get_device_dbc_list(self,device_id):
        import json 
        
        # If no match is found, the script simply applies all DBC files across any device ID
        device_dbc_list = [] 
        if device_id != "":
            fs_dbc_groups_file_path = self.tmp_input_dir / "dbc-groups.json"
            try:
                self.s3_client.download_file(self.bucket_input, "dbc-groups.json", str(fs_dbc_groups_file_path))
                self.logger.info(f"Downloaded DBC groups file to {fs_dbc_groups_file_path}")

                # Read the JSON file
                with open(fs_dbc_groups_file_path, "r") as file:
                    data = json.load(file)

                # Iterate over the groups in the JSON
                for group in data["dbc_groups"]:
                    self.logger.info(f"Evaluating DBC group {group}")
                    # Check if the device_id is in the current group
                    if device_id in group["devices"]:
                        # Add the dbc_files list to the variable
                        device_dbc_list = group["dbc_files"]
                        self.logger.info(f"Device specific DBC files: {device_dbc_list}")
                        break
            except Exception as e:
                self.logger.info(f"Applying all DBC files across all devices: {e}")
        
        return device_dbc_list
                        

    # Download DBC files
    def download_dbc_files(self, device_dbc_files):
        dbc_files = []
        
        for type in ["can", "lin"]:
            try:
                response = self.s3_client.list_objects_v2(Bucket=self.bucket_input, Prefix=type)
            except ValueError as ve:
                self.logger.error(f"Unable to list data from {self.bucket_input}:\n {ve}")
                result = False
            
            if "Contents" in response:
                for s3_object in response["Contents"]:
                    dbc_object_name = s3_object["Key"]
                    if dbc_object_name.endswith(".dbc") and (len(device_dbc_files) == 0 or dbc_object_name in device_dbc_files):
                        local_path = self.tmp_input_dir / dbc_object_name
                        self.s3_client.download_file(self.bucket_input, dbc_object_name, str(local_path))
                        dbc_files.append(dbc_object_name)
                        self.logger.info(f"Downloaded DBC to {local_path}")
        
        if len(dbc_files) == 0:
            self.logger.error(f"No DBC files with valid prefix in input bucket")
            result = False
        else:
            self.logger.info(f"Downloaded {len(dbc_files)} with valid prefix from input bucket")
            result = True
        
        return result


    # Download trigger log file
    def download_log_file(self):
        try:
            self.s3_client.download_file(self.bucket_input, str(self.s3_object_path), str(self.fs_log_file_path))
            self.logger.info(f"Downloaded MDF to {str(self.fs_log_file_path)}")
            result = True
        except Exception as e:
            self.logger.error(f"Failed to download MDF:\n{e}")
            result = False 
        
        return result
    
    # Download passwords.json file if needed
    def download_password_file(self):
        
        if self.fs_log_file_path.suffix in [".MFE", ".MFM"]:
            fs_passwords_file_path = self.tmp_input_dir / "passwords.json"
            try:
                self.s3_client.download_file(self.bucket_input, "passwords.json", str(fs_passwords_file_path) )
                self.logger.info(f"Downloaded passwords file to {fs_passwords_file_path}")
                result = True
            except Exception as e:
                self.logger.error(f"{self.fs_log_file_path.suffix} is encrypted, but no passwords.json found in {self.bucket_input}/\n{e}")
                result = False
        else:
            result = True
                
        return result
    
    
    # Process the MDF file using the MF4 decoder
    def process_log_file(self):
        import subprocess, os
        
        subprocess.run(["cp", "./" + self.decoder, self.tmp_input_dir])
        subprocess.run([os.path.join(self.tmp_input_dir, self.decoder), "-v"], cwd=str(self.tmp_input_dir),)
        subprocess_result = subprocess.run([os.path.join(self.tmp_input_dir, self.decoder),"-i",str(self.fs_log_file_path),"-O",str(self.tmp_output_dir), "--verbosity=1","-X",],cwd=str(self.tmp_input_dir),)
                
        if subprocess_result.returncode != 0:
            self.logger.error(f"MF4 decoding failed (returncode {subprocess_result.returncode})")
            result = False 
        else:
            self.logger.info(f"MF4 decoding created {len(list(self.tmp_output_dir.rglob('*.*'))) } Parquet files")
            result = True 
    
        return result

# -----------------------------------------------------------
# Below are useful functions for customizing your Lambda (see CANedge Intro for details)

# Upload all files in dir to S3 bucket_output
def upload_files_to_s3(s3_client, bucket_output, dir):
    import logging
    
    logger = logging.getLogger()
    uploaded_files = 0
    files = list(dir.rglob(f"*.*"))
    
    if s3_client == None or bucket_output == None:
        logger.info(f"S3 client and S3 output bucket must be specified to upload data from {dir}")
        return False
    
    for file in files:
        s3_path = str(file.relative_to(dir)).replace("\\","/")
        try:
            s3_client.upload_file(str(file), bucket_output, s3_path)
            uploaded_files += 1
        except Exception as e:
            logger.error(f"Failed to upload {file}: {e}")
    
    if uploaded_files != len(files):
        logger.error(f"{uploaded_files} files were uploaded out of {len(files)}")
        result = False
    else:
        logger.info(f"Successfully uploaded all {uploaded_files} files to {bucket_output} from {dir}") 
        result = True 
        
    return result 

# Load Parquet file to data frame (optionally rename columns for uniqueness, optionally resample)
def load_parquet_to_df(fs_output_file, message, raster="", prefix=False):
    import pyarrow.parquet as pq
    import pandas as pd

    table = pq.read_table(fs_output_file)
    df = table.to_pandas()
    df["t"] = pd.to_datetime(df["t"])
    df.set_index("t", inplace=True)

    if prefix:
        df.columns = [f"{message}_{col}" for col in df.columns]
    
    if raster != "":
        df = df.resample(raster).ffill(limit=1)
        df.index = df.index.round(raster)
        df = df.dropna(how='all')
        
    return df

# Build a dictionary of valid paths with key tuples of devices, dates, file_names and messages as values.
def get_related_message_paths(decoded_files, messages_filtered=[]):
    related_message_paths = {}
    
    # Iterate over all decoded files, create keys from path components and add messages as values
    for decoded_file in decoded_files:
        p = decoded_file.parts
        device, message, yyyy, mm, dd, file_name = p[-6], p[-5], p[-4], p[-3], p[-2], p[-1]
        date = f"{yyyy}/{mm}/{dd}"
        key = (device, date, file_name)
        
        if key not in related_message_paths:
            related_message_paths[key] = []
        
        related_message_paths[key].append(message)
    
    # If messages_filtered is provided, reduce the messages to filtered subset and ensure all are present
    if messages_filtered:
        related_message_paths = {
            key: [msg for msg in msgs if msg in messages_filtered]  # Reduce to relevant messages
            for key, msgs in related_message_paths.items()
            if all(msg in msgs for msg in messages_filtered)  # Ensure all filtered messages are present
        }

    return related_message_paths

# Send message to SNS topic (e.g. for use in email alerts)
def publish_message_to_sns(sns_client, arn, subject, body, logger):       
    try:
        response = sns_client.publish(
            TopicArn=arn,
            Subject=subject,
            Message=body,
            MessageAttributes={'DeduplicationId': {'DataType': 'String','StringValue': subject.replace(' ', '_').replace("|","")}}
        )
        logger.info(f"Published message with subject '{subject}' to SNS topic: {arn}")
        return True
    except Exception as e:
        logger.error(f"Error publishing to SNS: {e}")
        return False

# Haversine function to calculate distance in km between two lat/lon points (used in calculated signals example)
def haversine(lat1, lon1, lat2, lon2):
    import math 
        
    lat1_rad, lon1_rad = math.radians(lat1), math.radians(lon1)
    lat2_rad, lon2_rad = math.radians(lat2), math.radians(lon2)
    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad
    a = math.sin(dlat / 2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    distance_in_km = 6371.0 * c
    
    return distance_in_km

# Function to check if a point is inside any geofence and return the name and ID
def check_geofence(row, signal_latitude, signal_longitude, geofences):
    lat, lon = row[signal_latitude], row[signal_longitude]
    
    for geofence in geofences:
        geofence_id, geofence_name, (geofence_lat, geofence_lon), geofence_radius = geofence
        distance_in_km = haversine(lat, lon, geofence_lat, geofence_lon)
        
        if distance_in_km <= geofence_radius:
            return geofence_id

    return 0 # return 0 if no geofence is matched