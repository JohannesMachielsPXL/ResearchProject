# Upload all files in decoded_dir to S3 bucket_output
def process_decoded_data(s3_client, sns_client, bucket_output, decoded_dir):   
    from utils import upload_files_to_s3 
    
    result = upload_files_to_s3(s3_client, bucket_output, decoded_dir) 
    
    return result