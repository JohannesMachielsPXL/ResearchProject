# MF4 decoder version: v24.10.17
# Lambda script version: 2.2.0
import boto3, tempfile, logging, json
from pathlib import Path
from urllib.parse import unquote_plus

from utils import ProcessMdfData
from functions import process_decoded_data

s3_client = boto3.client("s3")
sns_client = boto3.client("sns")

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):   
    logger.info(f"Trigger event: {event}")
    result = True
    
    with tempfile.TemporaryDirectory() as temp:
        # Initialize variables
        decoder = "mdf2parquet_decode"
        bucket_input = event["Records"][0]["s3"]["bucket"]["name"]
        bucket_output = bucket_input  + "-parquet"
        s3_object_path = Path(unquote_plus(event["Records"][0]["s3"]["object"]["key"]))
        tmp_input_dir = Path(temp) / "input"
        tmp_output_dir = Path(temp) / "output"  
          
        tmp_input_dir.mkdir()
        tmp_output_dir.mkdir() 
            
        # Initialize MDF processing class and get device ID and device specific DBC list
        pmd = ProcessMdfData(s3_client, decoder, bucket_input, s3_object_path, tmp_input_dir, tmp_output_dir)
        device_id = pmd.extract_device_id()
        device_dbc_list = pmd.get_device_dbc_list(device_id)       

        # Download DBC file(s), log file and password file - then process via decoder
        dbc_result = pmd.download_dbc_files(device_dbc_list)
        if dbc_result:               
            pmd.download_log_file()
            pmd.download_password_file()
            decoder_result = pmd.process_log_file()
            
            # Process resulting decoded files
            if decoder_result:              
                process_result = process_decoded_data(s3_client, sns_client, bucket_output, tmp_output_dir)
    
    # Print and return the final result        
    if process_result:  
        result = {"statusCode": 200, "body": "Lambda execution succeeded"}
        logger.info(result)   
        return result 
    else:      
        result = {"statusCode": 400, "body": "Lambda execution failed"}
        logger.error(result)
        raise Exception("Manual exception to trigger Lambda Error (for alerting)")  
    
    